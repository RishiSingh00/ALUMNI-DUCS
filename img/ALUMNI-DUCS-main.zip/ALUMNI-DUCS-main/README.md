# ALUMNI-DUCS

DESIGN FILE
https://www.figma.com/file/z44mfmP4bWIPjoaSN9vStP/Alumni?node-id=0%3A1&t=8YDFqpEViMMmtRr1-1

TODO : 
https://docs.google.com/document/d/1oUZPtfylpEgwVEqM5pVZtwAqiu-vUi4ivsWFJ2DVSWI/edit?usp=sharing
